import java.util.Scanner;
public class Task03 {
    public static void main (String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Please Enter Height:");
        int size = sc.nextInt();
        for(int heightC=1; heightC<=size; ++heightC){
            for(int numberC=1; numberC<=heightC; ++numberC) {
                System.out.print(numberC);
            }
            System.out.println();
        }
    }
}